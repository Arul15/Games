//
//  LevelNormalLayer.h
//  talele
//
//  Created by Maxwell Dayvson da Silva on 9/14/12.
//  Copyright 2012 Terra. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "LevelBaseLayer.h"
@interface LevelNormalLayer : LevelBaseLayer {
    
}
+(CCScene *) scene;
@end
