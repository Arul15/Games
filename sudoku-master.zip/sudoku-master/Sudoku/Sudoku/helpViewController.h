//
//  helpViewController.h
//  Sudoku
//
//  Created by Xia Zhiyong on 12-2-15.
//  Copyright 2012年 amoeba workshop. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface helpViewController : UIViewController


- (IBAction)backHome;


@end
