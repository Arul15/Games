//
//  ViewController.h
//  DropShape
//
//  Created by Michael Behan on 06/02/2014.
//  Copyright (c) 2014 Michael Behan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SimplePathDrawingView.h"

@interface ViewController : UIViewController<SimplePathDrawingDelegate>

@property (weak, nonatomic) IBOutlet SimplePathDrawingView *drawingView;


@end
