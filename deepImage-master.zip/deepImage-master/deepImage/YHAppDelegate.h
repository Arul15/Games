//
//  YHAppDelegate.h
//  deepImage
//
//  Created by Yihhann on 13/5/19.
//  Copyright (c) 2013 Yihhann. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YHAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
