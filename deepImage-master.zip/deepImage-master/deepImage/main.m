//
//  main.m
//  deepImage
//
//  Created by Yihhann on 13/5/19.
//  Copyright (c) 2013年 Yihhann. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "YHAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([YHAppDelegate class]));
    }
}
