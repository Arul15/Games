//
//  YHMatchingCell.h
//  deepImage
//
//  Created by Yihhann on 13/6/15.
//  Copyright (c) 2013 Yihhann. All rights reserved.
//  Remark:
//    The only purpose of this class is to add an image to animate.

#import <UIKit/UIKit.h>

@interface YHMatchingCell : UICollectionViewCell
@property (retain, nonatomic) IBOutlet UIImageView *imageInside;

@end
